"""Lightweight color-curve digitizer for screenshots of the heat-pump graph.
Requires Pillow. Coordinates are calibrated by the user; output remains estimated.
"""
from PIL import Image
from collections import Counter
from datetime import datetime, timedelta
import math

def _matches(r,g,b,curve):
    if curve == 'green':
        return g > 75 and g > r*1.25 and g > b*1.12
    return r > 110 and r > g*1.22 and r > b*1.12

def digitize(path, date, x_left, x_right, y_top, y_bottom, y_min, y_max, curve):
    im=Image.open(path).convert('RGB')
    w,h=im.size
    xl=max(0,min(w-1,int(x_left))); xr=max(xl+1,min(w,int(x_right)))
    yt=max(0,min(h-1,int(y_top))); yb=max(yt+1,min(h,int(y_bottom)))
    if xr-xl < 20 or yb-yt < 20 or y_max <= y_min: raise ValueError('Ungültige Achsenkalibrierung.')
    # Find colored curve pixels per x column; use median y to suppress antialiasing noise.
    samples=[]
    px=im.load()
    for x in range(xl,xr):
        ys=[]
        for y in range(yt,yb):
            if _matches(*px[x,y],curve): ys.append(y)
        if ys: samples.append((x, sorted(ys)[len(ys)//2]))
    if len(samples)<8: raise ValueError('Zu wenige Kurvenpixel gefunden. Bitte Plotbereich/Farbe prüfen.')
    # Collapse adjacent pixels into curve samples and retain meaningful vertices/shape changes.
    # First smooth by a small median window, then keep endpoints and direction changes.
    sm=[]
    for i,(x,y) in enumerate(samples):
        win=[v for _,v in samples[max(0,i-2):min(len(samples),i+3)]]
        sm.append((x,sorted(win)[len(win)//2]))
    candidates=[]
    for i,(x,y) in enumerate(sm):
        if i==0 or i==len(sm)-1:
            candidates.append((x,y)); continue
        dx1=sm[i][0]-sm[i-1][0]; dx2=sm[i+1][0]-sm[i][0]
        s1=(sm[i][1]-sm[i-1][1])/max(1,dx1); s2=(sm[i+1][1]-sm[i][1])/max(1,dx2)
        if abs(s1-s2)>0.12 and (abs(y-sm[i-1][1])>=1 or abs(y-sm[i+1][1])>=1): candidates.append((x,y))
    # Also preserve plateau boundaries; never invent intermediate plateau points.
    compact=[]
    for p in candidates:
        if not compact or p[0]-compact[-1][0]>=3: compact.append(p)
        elif abs(p[1]-compact[-1][1])>1: compact.append(p)
    result=[]
    start=datetime.fromisoformat(date+'T00:00:00')
    for x,y in compact:
        minute=(x-xl)/(xr-xl)*1440
        ts=(start+timedelta(minutes=minute)).isoformat(timespec='minutes')
        val=y_max-(y-yt)/(yb-yt)*(y_max-y_min)
        result.append({'ts':ts,'value_kw':round(max(y_min,min(y_max,val)),3),'pixel_x':x,'pixel_y':y,'confidence':0.55})
    # infer cadence only where x separations are regular; this is descriptive, not a resampling step
    diffs=[(b['pixel_x']-a['pixel_x'])*1440/(xr-xl) for a,b in zip(result,result[1:]) if b['pixel_x']>a['pixel_x']]
    cadence=round(sorted(diffs)[len(diffs)//2]) if diffs else None
    return result,cadence
