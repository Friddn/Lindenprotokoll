# Lindenprotokoll update package

## Included in this package

This update adds the shared six-digit PIN access gate while preserving the existing application pages and SQLite schema/data:

- First startup migration creates a hash for the temporary PIN `000000` and forces the user to replace it.
- PINs are stored using Werkzeug's password-hashing functions, not as plain text.
- Users can change the PIN under **Sicherheit**.
- Failed attempts trigger a short session-based delay.
- Flask's signing secret is generated once and persisted in `/data/flask_secret_key` instead of using a fixed source-code secret.

## Install carefully

1. Stop the Lindenprotokoll add-on.
2. Back up the complete persistent `/data` directory, especially `lindenprotokoll.db`.
3. Back up the currently installed add-on/source folder.
4. Replace the add-on source files with the contents of this package and rebuild/reinstall the add-on using your normal Home Assistant workflow.
5. Start the add-on and open the app. The temporary PIN is `000000`; immediately set a new six-digit PIN when prompted.
6. Verify existing history, entries, settings, exports and normal workflows before relying on the update.

Do not delete or replace `/data`. The database migration is additive and does not intentionally delete existing records.

## Rollback

Stop the add-on, restore the previous application source, and restart. Restore the `/data` backup only if the database was changed unexpectedly; do not routinely replace a newer database with an older backup.

## Security scope

This is a basic shared-PIN gate for a trusted local network, not a substitute for HTTPS, a VPN, firewall restrictions or secure Home Assistant access controls. Do not expose the app's port directly to the public internet. The failed-attempt delay is session-based and should not be treated as strong protection against a determined attacker.

## Not included yet

The following requested features are not implemented in this package and must not be considered available:

- Heat-pump / non-heat-pump / total electricity breakdown.
- Hourly Tornesch temperature history and dual-axis comparison graph.
- Screenshot graph digitization and historical measurement reconstruction.

Those require the corresponding source data and a separate tested implementation. This package deliberately does not create synthetic measurements or alter existing consumption records.
