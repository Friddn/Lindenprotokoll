import tempfile
import unittest
from pathlib import Path

from PIL import Image, ImageDraw

from lindenprotokoll.app.graph_digitizer import digitize


class GraphDigitizerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.image_path = Path(self.temp.name) / "graph.png"
        image = Image.new("RGB", (800, 400), "white")
        draw = ImageDraw.Draw(image)
        draw.line(
            [(50, 300), (180, 260), (300, 260), (420, 200), (560, 200), (740, 250)],
            fill=(0, 180, 60), width=4,
        )
        draw.line(
            [(50, 350), (200, 300), (350, 310), (500, 240), (740, 270)],
            fill=(210, 40, 40), width=4,
        )
        image.save(self.image_path)

    def tearDown(self):
        self.temp.cleanup()

    def test_green_and_red_curves_are_detected(self):
        for curve in ("green", "red"):
            points, cadence = digitize(
                str(self.image_path), "2026-11-12", 50, 740, 50, 370, 0, 10, curve
            )
            self.assertGreaterEqual(len(points), 3)
            self.assertTrue(all(0 <= p["value_kw"] <= 10 for p in points))
            self.assertTrue(all(p["confidence"] < 1 for p in points))
            self.assertTrue(all("point_kind" in p for p in points))
            # Cadence is intentionally unknown unless repeated spacing is found.
            self.assertTrue(cadence is None or cadence > 0)

    def test_invalid_axis_range_is_rejected(self):
        with self.assertRaises(ValueError):
            digitize(str(self.image_path), "2026-11-12", 50, 740, 50, 370, 10, 0, "green")

    def test_invalid_date_is_rejected(self):
        with self.assertRaises(ValueError):
            digitize(str(self.image_path), "not-a-date", 50, 740, 50, 370, 0, 10, "green")


if __name__ == "__main__":
    unittest.main()
