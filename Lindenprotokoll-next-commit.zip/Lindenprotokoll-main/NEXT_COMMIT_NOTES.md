# Next commit: screenshot daily totals + curve analysis review

## Changes

- Adds `daily_hp_totals`, an additive SQLite table for confirmed daily heat-pump electricity (kWh/day) and thermal energy (kWh/day) read from screenshot labels.
- Adds an explicit per-screenshot review form. The user enters the printed numbers and confirms them; these values are marked `screenshot-manual` / `confirmed` and are authoritative for the daily heat-pump chart.
- Adds optional local Tesseract OCR (`tesseract` executable must be installed separately). OCR output is only a text suggestion and is never automatically imported as a numeric reading.
- Adds an OCR text field to `graph_screenshots` through a backwards-compatible additive migration.
- Daily statistics now prefer confirmed screenshot electricity totals. If no confirmed daily total exists, they fall back to the sum of imported hourly energy values. The API identifies the source.
- Fixes the daily combined-consumption line so it remains blank unless both heat-pump and non-heat-pump daily values are known.
- Existing meter records and original screenshot files are not modified by this feature.

## Data semantics

- `daily_hp_totals.electricity_kwh` is the printed daily heat-pump electricity total.
- `daily_hp_totals.thermal_kwh` is the printed daily thermal-energy total.
- `hp_graph_points` remains estimated curve geometry (kW at candidate timestamps), not source measurements.
- The screenshot total is not adjusted to force agreement with the digitized curve. A discrepancy should be reviewed; the printed total remains authoritative.
- OCR is optional. Without Tesseract, users can enter the clearly printed totals manually. OCR does not currently locate a particular label region or reliably associate a recognized number with a field; human confirmation is required.

## Validation performed

- Python AST parsing and `compileall` passed for application Python files.
- Full Flask/Home Assistant runtime tests were not run in this environment because Flask is not installed here.
- Please test on a copy of the Home Assistant add-on and a copy of `/data` before deploying to the live Pi.

## Commit / deployment

1. Create a feature branch in GitHub and add the contents of this ZIP (not the enclosing ZIP directory) on top of the current repository.
2. Review the diff; do not replace your live `/data` directory.
3. Back up Home Assistant `/data` and the current add-on version.
4. Build and test the add-on against a copy of the existing database before merging to `main`.
